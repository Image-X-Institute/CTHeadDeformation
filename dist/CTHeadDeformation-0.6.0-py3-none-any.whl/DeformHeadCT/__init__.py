"""
CT Head Deformation is a python library that allows for realistic simulation of head motion. 
"""
__version__ = '0.6.0'
__author__ = 'Mark Gardner'
